<?php
	include 'php/link_db.php';
	include 'php/corzina.php';
	include 'php/prof_info.php';
?>

<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/style.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon">
					<?php 
						if(isset($_COOKIE['login'])) { 
							echo "<a href='profile.html.php' class='nav-link'>". $user['first_name'] ."</a>";
						} else {
							echo '<a href="exit.html.php" class="nav-link">ВХОД</a>';
						}
					?>
				</li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'?>
			</ul>
		</nav>
		<main class="catalog">
			<section class="filter block">
				<form method="post">
					<h4>ФИЛЬТРЫ</h4>
					<p>Цена:</p>
					<div style="display: flex;">
						<input type="number" style="margin-right: 8px;" placeholder="от 15 р." name="price-filter-min">
						<input type="number" style="margin-left: 8px;" placeholder="до 50 000 р."  name="price-filter-max">
					</div>
					<h4>СОРТИРОВКА</h4>
					<div style="display: flex; flex-direction: column; justify-content: start;">
						<div class="radio">
							<input type="radio" name="sort-filter" value="По убыванию" />
							<label>По убыванию</label>
						</div>
						<div class="radio">
							<input type="radio" name="sort-filter" value="По возрастанию" />
							<label>По возрастанию</label>
						</div><br><br>
						<button type="submit" class="btn" name="filter">Применить</button>
					</div>
				</form>
			</section>
			<section class="carts">
			<?php
			// if(isset($_POST['filter'])){
			// 	$min_price = isset($_GET['price-filter-min']) ? $_GET['price-filter-min'] : 0;
			// 	$max_price = isset($_GET['price-filter-max']) ? $_GET['price-filter-max'] : PHP_INT_MAX;
			// 	$sort_order = isset($_GET['sort-filter']) ? $_GET['sort-filter'] : 'ASC';
				
			// 	$sql = "SELECT id, img, name_prod, price, description, subcategory_id 
			// 			FROM products
			// 			WHERE price BETWEEN $min_price AND $max_price
			// 			ORDER BY price $sort_order";
				
			// 	$result = $conn->query($sql);
				
			// 	while ($row = $result->fetch_assoc()) {
					
			// 	}
			// }
			if(isset($_GET['cat_id']) && $_GET['cat_id'] == 1){
				$sql = "SELECT id, img, name_prod, price, description, subcategory_id FROM products";
				$result = $conn->query($sql);
	
				while($row = $result->fetch_assoc()) {
			 ?>
				 <div class="card block">
					<div class="card__top">
						<a href="#" class="card__image">
							<img
							src="<?php echo $row['img']; ?>"
							alt="image"
							/>
						</a>
						<div class="card__label">Скорей покупай!</div>
					</div>
					<div class="card__bottom">
							<p class="price"><?php echo $row['price']; ?> Р.</p>
							<a href="product-details.html.php?prod_id=<?php echo $row['id']; ?>" class="card__title">
							<?php echo $row['name_prod']; ?>
						</a>
						<form method="post">
							<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
							<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor">
							<input type="submit" value="В корзину" name="add_to_cart" class="card__add">
						</form>
					</div>
			 </div>
			<?php
				}
			}
			if(isset($_GET['cat_id']) && $_GET['cat_id'] == 1){
				$sql = "SELECT id, img, name_prod, price, description, subcategory_id FROM products";
				$result = $conn->query($sql);
	
				while($row = $result->fetch_assoc()) {
			 ?>
				 <div class="card block">
					<div class="card__top">
						<a href="#" class="card__image">
							<img
							src="<?php echo $row['img']; ?>"
							alt="image"
							/>
						</a>
						<div class="card__label">Скорей покупай!</div>
					</div>
					<div class="card__bottom">
							<p class="price"><?php echo $row['price']; ?> Р.</p>
							<a href="product-details.html.php?prod_id=<?php echo $row['id']; ?>" class="card__title">
							<?php echo $row['name_prod']; ?>
						</a>
						<form method="post">
							<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
							<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor">
							<input type="submit" value="В корзину" name="add_to_cart" class="card__add">
						</form>
					</div>
			 </div>
			<?php
				}
			}
			if(isset($_GET['cat_id'])){
				$catId = isset($_GET['cat_id']) ? $_GET['cat_id'] : 0;

					$sql = "SELECT
						products.id,
						products.name_prod,
						products.price,
						products.img,
						subcategories.name,
						categories.name
					FROM
						products
					LEFT JOIN
						subcategories ON products.subcategory_id = subcategories.id
					LEFT JOIN
						categories ON subcategories.category_id = categories.id
					WHERE
						categories.id = " . $catId;

					$stmt = $conn->prepare($sql);
					$stmt->execute();
					$result = $stmt->get_result();

						while($row = $result->fetch_assoc()) {
							?>
							<div class="card block">
							<div class="card__top">
							<a href="#" class="card__image">
								<img
								src="<?php echo $row['img']; ?>"
								alt="image"
								/>
							</a>
							<div class="card__label">Скорей покупай!</div>
							</div>
							<!-- Нижняя часть -->
							<div class="card__bottom">
								<p class="price"><?php echo $row['price']; ?> Р.</p>
							<!-- Ссылка-название товара -->
							<a href="product-details.html.php?prod_id=<?php echo $row['id']; ?>" class="card__title">
								<?php echo $row['name_prod']; ?>
							</a>
							<form method="post">
								<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
								<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor">
								<input type="submit" value="В корзину" name="add_to_cart" class="card__add">
							</form>
							</div>
						</div>
					<?php
					}
			}
			if(isset($_GET['subcat_id'])){
					$id = isset($_GET['subcat_id']) ? $_GET['subcat_id'] : 0;

					$sql = "SELECT * FROM products WHERE subcategory_id = " . $id;
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
				?>
					<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="<?php echo $row['img']; ?>"
						alt="image"
						/>
					</a>
					<div class="card__label">Скорей покупай!</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p class="price"><?php echo $row['price']; ?> Р.</p>
						<!-- Ссылка-название товара -->
						<a href="product-details.html.php?prod_id=<?php echo $row['id']; ?>" class="card__title">
							<?php echo $row['name_prod']; ?>
						</a>
						<form method="post">
							<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
							<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor">
							<input type="submit" value="В корзину" name="add_to_cart" class="card__add">
						</form>
					</div>
				</div>
			<?php
				}
			}
		}
		?>
			</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
