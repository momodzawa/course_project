<?php
	include 'php/link_db.php';
	include 'php/prof_info.php';
	// include 'php/edit_prof.php';
?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/profile.css" rel="stylesheet" />
		<link href="style/registration.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon">
					<?php 
						if(isset($_COOKIE['login'])) { 
							echo "<a href='profile.html.php' class='nav-link'>". $user['first_name'] ."</a>";
						} else {
							echo '<a href="exit.html.php" class="nav-link">ВХОД</a>';
						}
					?>
				</li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
				<?php
				if(isset($_COOKIE['login'])) { 
				?>
				<li class="list" style="display: flex"><img src="img/exit.png" alt="image" class="icon" width="70">
					<form method="post">
						<input type="submit" name="exite" value="ВЫЙТИ" class="exite">
					</form>
				</li>
				<?php
				}
				?>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'?>
			</ul>
		</nav>
		<main class="profile">
			<section class="first">
				<?php
				if(!isset($_COOKIE['login'])){
					echo '<center><h2>Войдите в аккаунт чтобы увидеть информацию о вашем профиле</h2></center>';
				} else {
				?>
				<h2>Личный кабинет</h2>
				<div class="person">
					<div>
						<img src="img/person.jpg" alt="Фото пользователя" width="200">
					</div>
					<div>
						<p><h3>Привет, <?php echo $user['first_name']; ?>!</h3><?php echo $user['email']; ?></p>
						<form method="post">
							<input type="hidden" name="id" value="<?php echo $user['id']; ?>">
							<input type="submit" name="profile_edit" value="Редактировать профиль" class="btn">
							<!-- <input type="submit" name="password_edit" value="Изменить пароль" class="btn_rev"> -->
						</form>
					</div>
				</div>
				<?php
					if(isset($_POST['profile_edit'])){
				?>
					<form class="registration-form" method="post">
						<h2>Редактирование профиля</h2>
						<div>
							<label for="first_name">Имя:</label>
							<input type="text" id="first_name" name="first_name" value="<?php echo $user['first_name'] ?>">
						</div>
						<div>
							<label for="last_name">Фамилия:</label>
							<input type="text" id="last_name" name="last_name" value="<?php echo $user['last_name'] ?>">
						</div>
						<div>
							<label for="patronymic">Отчество:</label>
							<input type="text" id="patronymic" name="patronymic" value="<?php echo $user['patronymic'] ?>">
						</div>
						<div>
							<label for="email">Email:</label>
							<input type="email" id="email" name="email" value="<?php echo $user['email'] ?>">
						</div>
						<div>
							<label for="login">Логин:</label>
							<input type="text" id="login" name="login" value="<?php echo $user['login'] ?>">
						</div>
						<input type="hidden" name="id" value="<?php echo $user['id'] ?>">
						<input type="submit" class="btn" name="update_prof" value="Обновить информацию">
					</form>
				<?php
					}
					if(isset($_POST['update_prof'])){
						$id =  $_POST['id'];
						$first_name = $_POST['first_name'];
						$last_name = $_POST['last_name'];
						$patronymic = $_POST['patronymic'];
						$email =  $_POST['email']; 
						$login =  $_POST['login'];

						$sql = "UPDATE users SET first_name = '$first_name', last_name = '$last_name', patronymic = '$patronymic', email = '$email', login = '$login' where id = $id";

						if ($conn->query($sql) === TRUE) {
							echo "<script>alert('Информация успешно обновлена!');</script>";
						}
					}

					//if(isset($_POST['password_edit'])){
					 	?>
					 	<!-- <form method="post" class="registration-form">
					 		<h2>Изменение пароля</h2>
					 		<label for="current_password">Текущий пароль:</label>
					 		<input type="password" name="current_password" id="current_password">
					 		<br>
					 		<label for="new_password">Новый пароль:</label>
					 		<input type="password" name="new_password" id="new_password">
					 		<br>
					 		<input type="submit" name="change_password" value="Изменить пароль" class="btn">
					 	</form> -->
					 	<?php
					//}

					// if (isset($_POST['change_password'])) {
					// 	$current_password = $user['password'];
					// 	$new_password = $_POST['new_password'];
						
					// 	// Проверяем текущий пароль
					// 	if (password_verify($current_password, $_POST['current_password'])){
					// 		$sql = "UPDATE users SET password = '$new_password' WHERE login = " . $_COOKIE['login'];
					// 		$conn->query($sql);
					// 		echo "<script>alert('Пароль успешно изменен!!');</script>";
					// 	} else {
					// 		echo "<script>alert('Не верный текущий пароль!');</script>";
					// 	}
					// }
				?>
			</section>
			<section>
				<div class="orders">
					<h3>История заказов</h3>
					<ol>
					<?php
						$sql = "SELECT products.name_prod as names, products.price as price, products.img as img, products.id as id FROM products
								INNER JOIN detail_order ON products.id = detail_order.product_id
								INNER JOIN orders ON detail_order.order_id = orders.id
								WHERE orders.user_id = " .  $user['id'];

						$result = $conn->query($sql);

						if ($result->num_rows > 0) {
							while($detail_order = $result->fetch_assoc()) {
						?>
							<li>
								<img src="<?php echo $detail_order['img']; ?>" alt="prod_photo">
								<div>
									<p><a href="product-details.html.php?prod_id=<?php echo $detail_order['id']; ?>" class="card__title">
										<?php echo $detail_order['names']; ?>
									</a></p>
									<p><?php echo $detail_order['price']; ?></p>
									<form method="post">
										<input type="hidden" name="id" value="<?php echo $detail_order['id']; ?>">
										<input type="submit" name="review_add" value="Оставить отзыв" class="btn">
									</form>	
								</div>
							</li>
						<?php
							}
						} else {
							echo '<p>Сделайте первый заказ!</p>';
						}
						?>
					</ol>
				</div>
				<?php
				if(isset($_POST['review_add'])){
					$id = $_POST['id'];
				?>
				<div class="review">
					<form method="post" enctype="multipart/form-data">
						<h3>Оставить отзыв</h3>
						<div>
							<label>Оценка по 5-ти бальной шкале:</label><br>
							<input type="radio" name="count_star" value="5">5<br>
							<input type="radio" name="count_star" value="4">4<br>
							<input type="radio" name="count_star" value="3">3<br>
							<input type="radio" name="count_star" value="2">2<br>
						</div><br>
						<label>Добавить фото:</label><br>
						<input type="file" name="file"><br>
						<br>
						<textarea name="text" placeholder="подробнее опишите свое впечатление от товара, чтобы помочь другим пользователям с покупкой :)"></textarea><br>
						<input type="hidden" name="id" value="<?php echo $id ?>">
						<input type="submit" name="send_rev" class="btn" value="Отправить">
					</form>
				</div>
				<?php
				}
				if(isset($_POST['send_rev'])){
					$id = $_POST['id'];
					$count_star = $_POST['count_star'];
					$text = $_POST['text'];
					$user_id = $user['id'];
					$files = $_FILES['file'];

					$img = 'img/';
					$imgbox = $img . basename($files['name']);
						if(move_uploaded_file($files['tmp_name'], $imgbox)) {
						// Проверяем, есть ли уже отзыв пользователя на данный товар
						$sql_check = "SELECT * FROM reviews WHERE product_id = $id AND user_id = $user_id";
						$result_check = $conn->query($sql_check);

						if ($result_check->num_rows > 0) {
							$sql = "UPDATE reviews SET text = '$text', count_star = $count_star WHERE product_id = $id AND user_id = $user_id";
						} else {
							$sql = "INSERT INTO reviews (product_id, user_id, text, count_star, img) VALUES ($id, $user_id, '$text', $count_star, '$imgbox')";
						}

						if ($conn->query($sql) === TRUE) {
							echo "<script>alert('Отзыв успешно добавлен!');</script>";
						} else {
							echo "<script>alert('Ошибка при добавлении отзыва: " . $conn->error . "');</script>";
						}
					}
				}
				}
				?>
			</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
