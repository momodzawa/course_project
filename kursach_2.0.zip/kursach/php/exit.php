<?php
$err = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$login = $_POST['login'];
	$password = $_POST['password'];
	
	$stmt = $conn->prepare('SELECT * FROM users WHERE login = ?');
	$stmt->bind_param('s', $login);
	$stmt->execute();
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		$user = $result->fetch_assoc();
		if (password_verify($password, $user['password'])) {
			if($login == 'The_Best_Admin'){
				setcookie('admin', $login, time() + 3600);
				header('Location: admin.html.php?table_id=0');
			} else{
				setcookie('login', $login, time() + 3600);
				header('Location: profile.html.php');
			}
		} else {
			$err = 'Неверный пароль';
		}
	} else {
		$err = 'Такой учетной записи не существует, проверьте email!';
	}
}


?>