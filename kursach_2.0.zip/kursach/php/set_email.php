<?php
return [
	'mail_settings_prod' => [
		'host' => 'smtp.gmail.com',
		'auth' => true,
		'port' => 465,
		'secure' => 'ssl',
		'username' => 'hhlimyr08@gmail.com',
		'password' => 'pbeu nbbe qavy bguh',
		'charset' => 'UTF-8',
		'from_email' => 'hhlimyr08@gmail.com',
		'from_name' => 'Лапки',
		'is_html' => true

	]
]

?>