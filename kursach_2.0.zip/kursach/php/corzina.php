<?php
session_start();

// Логика добавления товара в избранное
if(isset($_POST['add_to_favor'])) {
	$product_id = $_POST['id'];
  
	// Если избранного ещё не существует, создаем новую
	if (!isset($_SESSION['favorite'])) {
	  $_SESSION['favorite'] = array();
	}
  
	// Добавляем товар в избранное, если он ещё не был добавлен
	if (!in_array($product_id, $_SESSION['favorite'])) {
	  $_SESSION['favorite'][] = $product_id;
	}
  
}

// Логика добавления товара в корзину
if(isset($_POST['add_to_cart'])) {
	$product_id = $_POST['id'];

	if (!isset($_SESSION['cart'])) {
		$_SESSION['cart'] = array();
	}

	if (!in_array($product_id, $_SESSION['cart'])) {
		$_SESSION['cart'][] = $product_id;
	}

}

//удаления товара из корзины
if(isset($_POST['delete'])){
	$product_id = $_POST['product_id'];
	$key = array_search($product_id, $_SESSION['cart']);
	if ($key !== false) {
		unset($_SESSION['cart'][$key]);
	}
}

//общая сумму заказа
$total_price = 0;
if (isset($_SESSION['cart'])) {
    foreach($_SESSION['cart'] as $product_id) {
        $sql = "SELECT price FROM products WHERE id = " . $product_id;
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $total_price += $row['price'];
        }
    }
}

if(isset($_POST['order'])){
	if(isset($_COOKIE['login'])) {
		header('Location: order-form.html.php');
	} else {
		echo "<script>alert('Перед оформлением заказа неопходимо авторизоваться.');</script>";
		header('Location: exit.html.php');
	}
}

?>