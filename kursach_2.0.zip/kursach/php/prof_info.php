<?php
//для обычного юзера
if (isset($_COOKIE['login'])) {
	$stmt = $conn->prepare('SELECT * FROM users WHERE login = ?');
	$stmt->bind_param('s', $_COOKIE['login']);
	$stmt->execute();
	$result = $stmt->get_result();
	$user = $result->fetch_assoc();
}

if(isset($_POST['exite'])){
	setcookie("login", "", time() - 3600); 
}

?>