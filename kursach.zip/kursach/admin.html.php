<?php
include 'php/link_db.php';
include 'php/prof_info_adm.php';

session_start();
//заказы
if (isset($_POST['delete']) && $_GET['table_id'] == 1) {
  $id = $_POST['id'];
  $sql = "DELETE FROM orders WHERE id = $id";
  $conn->query($sql);
}

//учетные записи  
if (isset($_POST['delete']) && $_GET['table_id'] == 2) {
	$id = $_POST['id'];
	$sql = "DELETE FROM users WHERE id = $id";
	$conn->query($sql);
}

//товары
if (isset($_POST['delete']) && $_GET['table_id'] == 3) {
	$id = $_POST['id'];
	$sql = "DELETE FROM products WHERE id = $id";
	$conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/admin.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><a href="admin.html.php?table_id=0" class="nav-link">АДМИНИСТРАТОР</a></li>
				<li class="list"><a href="admin.html.php?table_id=1" class="nav-link">ЗАКАЗЫ</a></li>
				<li class="list"><a href="admin.html.php?table_id=2" class="nav-link">УЧЕТНЫЕ ЗАПИСИ</a></li>
				<li class="list"><a href="admin.html.php?table_id=3" class="nav-link">ТОВАРЫ</a></li>
				<li class="list" style="display: flex"><img src="img/exit.png" alt="image" class="icon" width="70">
					<form method="post">
						<input type="submit" name="exite" value="ВЫЙТИ" class="exite">
					</form>
				</li>
			</ul>
		</nav>
		<main class="flex">
		<section class="first">
				<h2>Личный кабинет</h2>
				<div class="person">
					<div>
						<img src="img/person.jpg" alt="Фото пользователя" width="200">
					</div>
					<div>
						<p><h3>Привет, <?php echo $user['first_name']; ?>!</h3><?php echo $user['email']; ?></p>
						<form method="post">
							<input type="hidden" name="id" value="<?php echo $user['id']; ?>">
							<input type="submit" name="profile_edit" value="Редактировать профиль" class="btn1">
							<!-- <input type="submit" name="password_edit" value="Изменить пароль" class="btn_rev"> -->
						</form>
					</div>
				</div>
				<?php
					if(isset($_POST['profile_edit'])){
				?>
					<form class="registration-form" method="post">
						<h2>Редактирование профиля</h2>
						<div>
							<label for="first_name">Имя:</label>
							<input type="text" id="first_name" name="first_name" value="<?php echo $user['first_name'] ?>">
						</div>
						<div>
							<label for="last_name">Фамилия:</label>
							<input type="text" id="last_name" name="last_name" value="<?php echo $user['last_name'] ?>">
						</div>
						<div>
							<label for="patronymic">Отчество:</label>
							<input type="text" id="patronymic" name="patronymic" value="<?php echo $user['patronymic'] ?>">
						</div>
						<div>
							<label for="email">Email:</label>
							<input type="email" id="email" name="email" value="<?php echo $user['email'] ?>">
						</div>
						<input type="hidden" name="id" value="<?php echo $user['id'] ?>">
						<input type="submit" class="btn" name="update_prof" value="Обновить информацию">
					</form>
				<?php
					}
					if(isset($_POST['update_prof'])){
						$id =  $_POST['id'];
						$first_name = $_POST['first_name'];
						$last_name = $_POST['last_name'];
						$patronymic = $_POST['patronymic'];
						$email =  $_POST['email']; 
						$login =  $_POST['login'];

						$sql = "UPDATE users SET first_name = '$first_name', last_name = '$last_name', patronymic = '$patronymic', email = '$email', login = '$login' where id = $id";

						if ($conn->query($sql) === TRUE) {
							echo "<script>alert('Информация успешно обновлена!');</script>";
						}
					}
				?>
			</section>
				<!-- формы для редактирования -->
				<div>
				<!-- товары -->
				<?php
					if(isset($_POST['add_new_product'])){
				?>
					<center><h2>Добавление нового товара</h2></center>
					<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="registration-form" enctype="multipart/form-data">
						<label>Наименование товара:</label>
						<input type="text" name="name_prod" required>
						<label>Цена:</label>
						<input type="number" name="price" required>
						<label>Описание:</label>
						<textarea name="description" required></textarea>
						<label>Фото товара:</label>
						<input type="file" name="file" required>
						<label>Подкатегория:</label>
						<select name="subcategory_id" required>
							<!-- Опции для выбора подкатегории -->
							<?php
							$sql_subcategories = "SELECT id, name FROM subcategories";
							$result = $conn->query($sql_subcategories);
							if ($result->num_rows > 0) {
								while ($row = $result->fetch_assoc()) {
									echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
								}
							}
							?>
						</select>

						<label>Поставщик:</label>
						<select name="provider_id" required>
							<!-- Опции для выбора поставщика -->
							<?php
							$sql_providers = "SELECT id, name FROM providers";
							$result = $conn->query($sql_providers);
							if ($result->num_rows > 0) {
								while ($row = $result->fetch_assoc()) {
									echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
								}
							}
							?>
						</select>
						<label>Количество:</label>
						<input type="number" name="count" required>
						<label>Сумма:</label>
						<input type="number" name="summ" required>
						<input type="submit" name="add_new_prod" value="Добавить товар" class="btn-form">
					</form>
				<?php
					}
					if(isset($_POST['add_new_prod'])){
						$name_prod = $_POST['name_prod'];
						$price = $_POST['price'];
						$description = $_POST['description'];
						$files = $_FILES['file'];
						$subcategory_id = $_POST['subcategory_id'];
						$provider_id = $_POST['provider_id'];
						$count = $_POST['count'];
						$summ = $_POST['summ'];

						$img = 'img/';
						$imgbox = $img . basename($files['name']);
							if(move_uploaded_file($files['tmp_name'], $imgbox)) {
								// Добавление нового товара в таблицу products
								$sql_products = "INSERT INTO products (img, name_prod, price, description, subcategory_id)
												VALUES ('$imgbox', '$name_prod', $price, '$description', $subcategory_id)";
							
								if ($conn->query($sql_products) === TRUE) {
									$last_product_id = $conn->insert_id; // Получение ID добавленного товара
							
									// Добавление информации о поставщике в таблицу product_details
									$sql_details = "INSERT INTO detail_product (product_id, provider_id, count, sum)
													VALUES ($last_product_id, $provider_id, $count, $summ)";
							
									if ($conn->query($sql_details) === TRUE) {
										echo "Новый товар успешно добавлен в каталог";
									} else {
										echo "Ошибка при добавлении информации о поставщике: " . $conn->error;
									}
								} else {
									echo "Ошибка при добавлении товара: " . $conn->error;
								}
							}
						}	
					

					if (isset($_POST['edit']) && $_GET['table_id'] == 3) {
						$id = $_POST['id'];
						$sql = "SELECT * FROM products WHERE id = $id";
						$result = $conn->query($sql);
					
						if ($result->num_rows > 0) {
							$row = $result->fetch_assoc();
							?>
							<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"  class="registration-form">
								<h3>Редактирование товара</h3>
								<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
								<label>Наименование:</label>
								<input type="text" name="name_prod" value="<?php echo $row['name_prod']; ?>">
								<label>Цена:</label>
								<input type="number" name="price" value="<?php echo $row['price']; ?>">
								<label>Описание:</label>
								<textarea name="description"><?php echo $row['description']; ?></textarea>
								<label>Фото:</label>
								<input type="text" name="img" value="<?php echo $row['img']; ?>">
								<input type="submit" name="update_product" value="Сохранить" class="btn-form">
							</form>
							<?php
						} else {
							echo "Товар не найден";
						}
					}
					
					// Обновление товара
					if (isset($_POST['update_product'])) {
						$id = $_POST['id'];
						$name_prod = $_POST['name_prod'];
						$price = $_POST['price'];
						$description = $_POST['description'];
						$img = $_POST['img'];
					
						$sql = "UPDATE products SET img = '$img', name_prod = '$name_prod', price = $price, description = '$description' WHERE id = $id";
					
						if ($conn->query($sql) === TRUE) {
							header("Location: admin.html.php?table_id=3");
						} else {
							echo "Ошибка при обновлении: " . $conn->error;
						}
					}
					?>
					<!-- учетные записи -->
					<?php
					if (isset($_POST['edit']) && $_GET['table_id'] == 2) {
						$id = $_POST['id'];
						$sql = "SELECT * FROM users WHERE id = $id";
						$result = $conn->query($sql);
					
						if ($result->num_rows > 0) {
							$row = $result->fetch_assoc();
							?>
							<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"  class="registration-form">
								<h3>Редактирование учетной записи</h3>
								<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
								<label>Имя:</label>
								<input type="text" name="first_name" value="<?php echo $row['first_name']; ?>">
								<label>Фамилия:</label>
								<input type="text" name="last_name" value="<?php echo $row['last_name']; ?>">
								<label>Отчество:</label>
								<input type="text" name="patronymic" value="<?php echo $row['patronymic']; ?>">
								<label>Email:</label>
								<input type="email" name="email" value="<?php echo $row['email']; ?>">
								<input type="submit" name="update_user" value="Сохранить" class="btn-form">
							</form>
							<?php
						} else {
							echo "Товар не найден";
						}
					}
					
					// Обновление учетной записи
					if (isset($_POST['update_user'])) {
						$id = $_POST['id'];
						$first_name = $_POST['first_name'];
						$last_name = $_POST['last_name'];
						$patronymic = $_POST['patronymic'];
						$email = $_POST['email'];
					
						$sql = "UPDATE users SET first_name = '$first_name', last_name = '$last_name', patronymic = '$patronymic', email = '$email'  WHERE  id = $id";
					
						if ($conn->query($sql) === TRUE) {
							header("Location: admin.html.php?table_id=2");
						} else {
							echo "Ошибка при обновлении: " . $conn->error;
						}
					}
					
					?>
					<!-- заказы -->
					<?php
					if (isset($_POST['edit']) && $_GET['table_id'] == 1) {
						$id = $_POST['id'];
						$sql = "SELECT * FROM orders WHERE id = $id";
						$result = $conn->query($sql);
					
						if ($result->num_rows > 0) {
							$row = $result->fetch_assoc();
							?>
							<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"  class="registration-form">
								<h3>Редактирование заказа</h3>
								<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
								<label>Дата заказа:</label>
								<input type="date" name="date" value="<?php echo $row['date']; ?>">
								<label>Общая стоимость:</label>
								<input type="numder" name="final_amount" value="<?php echo $row['final_amount']; ?>">
								<label>Покупатель:</label>
								<input type="text" name="user_id" value="<?php echo $row['user_id']; ?>">
								<label>Статус:</label>
								<input type="text" name="status" value="<?php echo $row['status']; ?>">
								<input type="submit" name="update_order" value="Сохранить" class="btn-form">
							</form>
							<?php
						} else {
							echo "Товар не найден";
						}
					}
					
					// Обновление заказа
					if (isset($_POST['update_order'])) {
						$id = $_POST['id'];
						$date = $_POST['date'];
						$final_amount = $_POST['final_amount'];
						$user_id = $_POST['user_id'];
						$status = $_POST['status'];
					
						$sql = "UPDATE orders SET date = '$date', final_amount = $final_amount, user_id = $user_id, status = '$status'  WHERE  id = $id";
					
						if ($conn->query($sql) === TRUE) {
							header("Location: admin.html.php?table_id=1");
						} else {
							echo "Ошибка при обновлении: " . $conn->error;
						}
					}
						?>
				</div>
			<!-- таблица по редактированию учетных записей -->
			<?php 
			if($_GET['table_id'] == 2){
			?>
			<h2>Учетные записи</h2>
			<table class="block">
				<tr style="font-weight: bold; font-size: 20px;">
					<td>Id</td>
					<td>Фамилия</td>
					<td>Имя</td>
					<td>Отчество</td>
					<td>Email</td>
					<td>Действия</td>
				</tr>
				<?php
					$sql = "SELECT * FROM users";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
				?>		
						<tr>
							<td><?php echo $row['id']; ?></td>
							<td><?php echo $row['first_name']; ?></td>
							<td><?php echo $row['last_name']; ?></td>
							<td><?php echo $row['patronymic']; ?></td>
							<td><?php echo $row['email']; ?></td>
							<td>
								<form method="post" class="wrap">
									<input type="hidden" name="id" value="<?php echo $row['id'];?>">
									<button class="btn" type="submit" name="edit">Редактировать</button>
									<button class="btn_rev" type="submit" name="delete">Удалить</button>
								</form>
							</td>
						</tr>
				<?php
						}
					}
				}
				?>
			</table>

			<!-- таблица по редактированию заказов -->
			<?php 
			if($_GET['table_id'] == 1){
			?>
			<h2>Заказы</h2>
            <table class="block">
                    <tr style="font-weight: bold; font-size: 20px;">
                        <td>Id</td>
                        <td>Дата заказа</td>
                        <td>Общая стоимость</td>
                        <td>Id пользователя</td>
						<td>Статус</td>
						<td>Действия</td>
                    </tr>
				<?php
					$sql = "SELECT * FROM orders";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
				?>		
						<tr>
							<td><?php echo $row['id']; ?></td>
							<td><?php echo $row['date']; ?></td>
							<td><?php echo $row['final_amount']; ?> p.</td>
							<td><?php echo $row['user_id']; ?></td>
							<td><?php echo $row['status']; ?></td>
							<td>
								<form method="post" class="wrap">
									<input type="hidden" name="id" value="<?php echo $row['id'];?>">
									<button class="btn" type="submit" name="edit">Редактировать</button>
									<button class="btn_rev" type="submit" name="delete">Удалить</button>
								</form>
							</td>
						</tr>
				<?php
						}
					}
				}
				?>
			</table>

			<!-- таблица по редактированию каталога товаров -->
			<?php 
			if($_GET['table_id'] == 3){
			?>
			<div class="header">
					<h2>Карточки товаров</h2>
					<form method="post">
						<button class="btn" type="submit" name="add_new_product">Добавить новый товар</button>
					</form>
				</div>
                <table class="block">
                    <tr style="font-weight: bold; font-size: 20px;">
                        <td>Id</td>
                        <td>Наименование</td>
                        <td>Цена</td>
                        <td>Описание</td>
						<td>Фото товара</td>
						<td>Действия</td>
                    </tr>
				<?php
					$sql = "SELECT * FROM products";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
				?>		
					<tr>
						<td><?php echo $row['id']; ?></td>
						<td><?php echo $row['name_prod']; ?></td>
						<td><?php echo $row['price']; ?> p.</td>
						<td class="scroll"><?php echo $row['description']; ?></td>
						<td><?php echo $row['img']; ?></td>
						<td>
							<form method="post" class="wrap">
								<input type="hidden" name="id" value="<?php echo $row['id'];?>">
								<button class="btn" type="submit" name="edit">Редактировать</button>
								<button class="btn_rev" type="submit" name="delete">Удалить</button>
							</form>
						</td>
					</tr>
				<?php
						}
					}
				}
				?>
			</table>
		</main>
		<footer class="page-footer">
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
