const app = Vue.createApp({ });
app.component('navigationpanel', {
    template: `<nav class="navigation">
    <div class="logo"><img src="img/logo 1.png" alt="logo"></div>
    <ul class="item start">
        <li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
        <li class="list"><img src="img/image 2.png" alt="image" class="icon"><a href="" class="nav-link">БОНУСЫ</a></li>
        <li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
    </ul>
</nav>
<nav class="navigation block" style="margin-top: 10px; margin-bottom: 20px;">
    <ul class="menu">
        <li class="menu-list"><a href="index.html.php" class="nav-link">АКЦИИ</a></li>
        <li class="menu-list"><a href="#" class="nav-link">КОШКИ</a></li>
        <li class="menu-list"><a href="#" class="nav-link">СОБАКИ</a></li>
        <li class="menu-list"><a href="#" class="nav-link">ГРЫЗУНЫ</a></li>
        <li class="menu-list"><a href="#" class="nav-link">ПТИЦЫ</a></li>
        <li class="menu-list"><a href="#" class="nav-link">РЫБЫ И РЕПТИЛИИ</a></li>
    </ul>
</nav> `
});
app.mount('#app');