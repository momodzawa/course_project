<?php
// session_start();
// if(!isset($_SESSION['cart'])){
//     $_SESSION['cart'] = array();
// }
// //добавляем элемент массива в конец массива(заполняем корзину)
// if(isset($_POST['action'] && $_POST['action'] == 'В корзину')){  
//     $_SESSION['cart'][] = $_POST['id'];
//     header('Location: .');
//     exit();
// }
// //добавление товара в корзину
// if(isset($_GET['cart'])){
//     $cart = array();
//     $total = 0;
//     foreach($_SESSION['cart'] as $id){
//         foreach($row as $product){
//             if($product['id'] == $id){
//                 $cart[] = $product;
//                 $total += $product['price'];
//                 break;
//             }
//         }
//     }
//     include '../../corzina.html.php';
//     exit();
// }
// //опустошаем массив(корзину)
// if(!empty($_POST['action'] && $_POST['action'] == 'очистить корзину')){
//     unset($_SESSION['cart']);
//     header('Location: ?cart');
//     exit();
// }
// include '../../index.html.php';

?>