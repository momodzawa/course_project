<?php
// $err = $err_pass = $err_email = '';
// // Проверка, была ли отправлена форма
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
// 	// Проверка наличия и валидация полей ФИО, почты и пароля
// 	$first_name = $last_name = $patronymic = $email = $password = $confirm_password = '';
// 	$err = $err_pass = $err_email ='';
  
// 	if (empty($_POST["first_name"]) || empty($_POST["last_name"]) || empty($_POST["email"]) || empty($_POST["password"]) || empty($_POST["confirm-password"]) || empty($_POST["patronymic"])) {
// 	  $err = "Все поля должны быть заполнены";
// 	} else {
// 	  $first_name = validate_input($_POST["first_name"]);
// 	  $last_name = validate_input($_POST["last_name"]);
// 	  $patronymic = validate_input($_POST["patronymic"]);
  
// 	  if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
// 		$err_email = "Неправильный формат электронной почты";
// 	  } else {
// 		$password = $_POST["password"];
// 		$confirm_password = $_POST["confirm-password"];
	
// 		if ($password != $confirm_password) {
// 			$err_pass = "Пароли не совпадают";
// 		} else {
// 		  $hashed_password = password_hash($password, PASSWORD_DEFAULT);
// 		}
// 	}
// }
  
// 	// Если все поля корректны, выполняем запись в базу данных
// 	if ($first_name && $last_name && $patronymic && $email && $password && $confirm_password) {
// 	// Подключение к базе данных
// 	$host = 'localhost';
// 	$db   = 'zoo_shop';
// 	$user = 'momodzawa';
// 	$pass = 'momo0808';
// 	$charset = 'utf8mb4';

// 	$conn = new mysqli($host, $user, $pass, $db);

// 	if ($conn->connect_error) {
// 	die("Соеденение: " . $conn->connect_error);
// 	}
  
// 	  // Подготовка и выполнение запроса
// 	  $stmt = $conn->prepare('INSERT INTO users (first_name, last_name, patronymic, email, password) VALUES (?, ?, ?, ?)');
// 	  $stmt->bind_param('sssss', $first_name, $last_name, $patronymic, $email, $hashed_password);
// 	  $stmt->execute();
  
// 	  header('Location: exit.html.php');
// 	}
//   }
  
//   function validate_input($data) {
// 	$data = trim($data);
// 	$data = stripslashes($data);
// 	$data = htmlspecialchars($data);
// 	return $data;
//   }
  
?>