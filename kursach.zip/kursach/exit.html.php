<?php
include 'php/link_db.php';
include 'php/exit.php';
?>

<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/exit.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'; ?>
			</ul>
		</nav>
		<main>
			<form class="login-form" method="post">
				<h1>Вход</h1>
				<div>
					<label for="login">Логин:</label>
					<input type="text" id="login" name="login" required>
				</div>
				<div>
					<label for="password">Пароль:</label>
					<input type="password" id="password" name="password" required>
				</div>
				<span style="color: red;"><?php echo $err; ?></span>
				<button type="submit" class="btn">Вход</button>
				<p>Если у вас нет аккаунта, то самое время <a href="registration.html.php">зарегистрироваться</a></p>
			</form>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
