<?php
	include 'php/link_db.php';
	include 'php/corzina.php';
	include 'php/prof_info.php';
?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/corzina.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon">
					<?php 
						if(isset($_COOKIE['login'])) { 
							echo "<a href='profile.html.php' class='nav-link'>". $user['first_name'] ."</a>";
						} else {
							echo '<a href="exit.html.php" class="nav-link">ВХОД</a>';
						}
					?>
				</li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'?>
			</ul>
		</nav>
		<main class="shop-cart-conteiner">
			<section>
			<?php
				if(isset($_SESSION['cart'])){
					foreach($_SESSION['cart'] as $product_id) {
					$sql = "SELECT id, name_prod, price, img FROM products WHERE id = ".$product_id;
					$result = $conn->query($sql);
							
					if ($result->num_rows > 0) {
						$row = $result->fetch_assoc();
					?>
					<table class="shop_cart block">
						<tr>
							<td><img src="<?php echo $row['img']; ?>" alt="image" class="img-in-cart" /></td>
							<td><a href="product-details.html.php?prod_id=<?php echo $row['id']; ?>" class="card__title"><?php echo $row['name_prod']; ?></a></td>
							<td><p class="price_in"><?php echo $row['price']; ?>p.</p></td>
							<td class="last">
								<form method="post">
									<input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
									<input type="submit" name="delete" class="delete" value="Удалить">
								</form>	
							</td>
						</tr>
					<?php	
					}
				}
				
			} else {
				echo "<h2>Корзина пуста!</h2>";
			}
			?>
				</table>
			</section>
			<section class="block buy">
				<h3>Итого</h3>
				<p><?php echo $total_price; ?> p.</p>
				<form method="post">
					<button class="card__buy" type="submit" name='order'>Оформить заказ</button>
				</form>
			</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
		</footer>
	</body>
</html>
