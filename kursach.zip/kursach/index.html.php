<?php
// Подключение к базе данных
$host = 'localhost';
$db   = 'zoo_shop';
$user = 'momodzawa';
$pass = 'momo0808';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Соеденение: " . $conn->connect_error);
}

session_start();
// Логика добавления товара в корзину
if(isset($_POST['add_to_cart'])) {
	$product_id = $_POST['id'];
  
	// Если корзина ещё не существует, создаем новую
	if (!isset($_SESSION['cart'])) {
	  $_SESSION['cart'] = array();
	}
  
	// Добавляем товар в корзину, если он ещё не был добавлен
	if (!in_array($product_id, $_SESSION['cart'])) {
	  $_SESSION['cart'][] = $product_id;
	}
  }

  // Логика добавления товара в корзину
if(isset($_POST['add_to_favor'])) {
	$product_id = $_POST['id'];
  
	// Если корзина ещё не существует, создаем новую
	if (!isset($_SESSION['favorite'])) {
	  $_SESSION['favorite'] = array();
	}
  
	// Добавляем товар в корзину, если он ещё не был добавлен
	if (!in_array($product_id, $_SESSION['favorite'])) {
	  $_SESSION['favorite'][] = $product_id;
	}
  
  }

?>

<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/style.css" rel="stylesheet" />
		<script src="https://cdnjs.cloudflare.com/ajax/libs/vue/3.2.30/vue.global.min.js"></script>
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php
					// Выборка категорий
					$sql = "SELECT * FROM categories";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					// Вывод категорий и их подкатегорий
					while($category = $result->fetch_assoc()) {
						echo '<li class="menu-list dropdown">
			 			<a class="nav-link" href="index.html.php?cat_id=' . $category['id'] . '" name="category_id">' . $category['name'] . '</a><div class="dropdown-content">';
						
						// Выборка подкатегорий для каждой категории
						$subSql = "SELECT * FROM subcategories WHERE category_id = " . $category['id'];
						$subResult = $conn->query($subSql);
						if ($subResult->num_rows > 0) {
							while($subcategory = $subResult->fetch_assoc()) {
								echo '<a href="?subcat_id=' . $subcategory['id'] . '" name="subcategory_id">' . $subcategory['name'] . '</a>';
							}
						} 
					}
				}
				?>
			</ul>
		</nav>
		<main class="catalog">
			<section class="filter block">
				<h4>ФИЛЬТРЫ</h4>
				<p>Цена:</p>
				<div style="display: flex;">
					<input type="number" style="margin-right: 8px;" placeholder="от 15 р." name="price-filter">
					<input type="number" style="margin-left: 8px;" placeholder="до 50 000 р."  name="price-filter">
				</div>
				  <h4>СОРТИРОВКА</h4>
				  <div style="display: flex; flex-direction: column; justify-content: start;">
					<div class="radio">
						<input type="radio" name="sort-filter" value="По убыванию" />
						<label>По убыванию</label>
					</div>
					<div class="radio">
						<input type="radio" name="sort-filter" value="По возрастанию" />
						<label>По возрастанию</label>
					</div><br><br>
					<button type="submit" class="btn">Применить</button>
				  </div>
			</section>
			<section class="carts">
			<?php
				$catId = isset($_GET['cat_id']) ? $_GET['cat_id'] : 0;

					$sql = "SELECT
						products.id,
						products.name_prod,
						products.price,
						products.img,
						subcategories.name,
						categories.name
					FROM
						products
					LEFT JOIN
						subcategories ON products.subcategory_id = subcategories.id
					LEFT JOIN
						categories ON subcategories.category_id = categories.id
					WHERE
						categories.id = " . $catId;

					$stmt = $conn->prepare($sql);
					$stmt->execute();
					$result = $stmt->get_result();

						while($row = $result->fetch_assoc()) {
							?>
							<div class="card block">
							<div class="card__top">
							<a href="#" class="card__image">
								<img
								src="<?php echo $row['img']; ?>"
								alt="image"
								/>
							</a>
							<div class="card__label">Скорей покупай!</div>
							</div>
							<!-- Нижняя часть -->
							<div class="card__bottom">
								<p><?php echo $row['price']; ?> Р.</p>
							<!-- Ссылка-название товара -->
							<a href="describe_card.html.php" class="card__title">
								<?php echo $row['name_prod']; ?>
							</a>
							<form method="post">
								<input type="hidden" name="id" value="<?php echo $row["id"]; ?>" style="margin-top: auto; margin-bottom: 10px;">
								<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor" style="margin-top: auto; margin-bottom: 10px;">
							</form>
							<form method="post">
								<input type="hidden" name="id" value="<?php echo $row["id"]; ?>" style="margin-top: auto; margin-bottom: 10px;">
								<input type="submit" value="В корзину" name="add_to_cart" class="card__add" style="margin-top: auto; margin-bottom: 10px;">
							</form>
							</div>
						</div>
					<?php
						}

					$id = isset($_GET['subcat_id']) ? $_GET['subcat_id'] : 0;

					$sql = "SELECT id, img, name_prod, price, description, subcategory_id FROM products WHERE subcategory_id = " . $id;
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
				?>
					<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="<?php echo $row['img']; ?>"
						alt="image"
						/>
					</a>
					<div class="card__label">Скорей покупай!</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p class="price"><?php echo $row['price']; ?> Р.</p>
					<!-- Ссылка-название товара -->
					<a href="describe_card.html.php" class="card__title">
						<?php echo $row['name_prod']; ?>
					</a>
					<form method="post">
						<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
						<input type="submit" value="В избранное" name="add_to_favor" class="add_to_favor">
					</form>
					<form method="post">
						<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
						<input type="submit" value="В корзину" name="add_to_cart" class="card__add">
					</form>
					</div>
				</div>
			<?php
			}
		}
			?>

			</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="" class="foot-link">Доставка и оплата</a></li>
					<li class="footer-list"><a href="" class="foot-link">Промокод</a></li>
					<li class="footer-list"><a href="" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="" class="foot-link">Контакты</a></li>
					<li class="footer-list"><a href="" class="foot-link">Адреса магазинов</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">Сервисы покупателя</p>
					<li class="footer-list"><a href="" class="foot-link">Подарочные сертифакы</a></li>
					<li class="footer-list"><a href="" class="foot-link">Бонусные карты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 2.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 3.png" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>		
	</body>
</html>
