<?php
// Подключение к базе данных
$host = 'localhost';
$db   = 'zoo_shop';
$user = 'momodzawa';
$pass = 'momo0808';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Соеденение: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/profile.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="profile.html.php" class="nav-link">ЕКАТЕРИНА</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php
					// Выборка категорий
					$sql = "SELECT * FROM categories";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					// Вывод категорий и их подкатегорий
					while($category = $result->fetch_assoc()) {
						echo '<li class="menu-list dropdown">
			 			<a class="nav-link" href="index.html.php?cat_id=' . $category['id'] . '" name="category_id">' . $category['name'] . '</a><div class="dropdown-content">';
						
						// Выборка подкатегорий для каждой категории
						$subSql = "SELECT * FROM subcategories WHERE category_id = " . $category['id'];
						$subResult = $conn->query($subSql);
						if ($subResult->num_rows > 0) {
							while($subcategory = $subResult->fetch_assoc()) {
								echo '<a href="?subcat_id=' . $subcategory['id'] . '" name="subcategory_id">' . $subcategory['name'] . '</a>';
							}
						} 
					}
				}
				?>
			</ul>
		</nav>
		<main class="profile">
			<section><img src="img/5 1ava.png"></section>
			<section>
				<h2>Привет, Екатерина!</h2>
				<p><a href="#">Мои заказы</a></p>
				<p><a href="#">Мои промокоды</a></p>
				<p><a href="#">Избранное</a></p>
				<p><a href="#">Личные данные и настройки</a></p>
				<p><a href="#">Адрес достваки</a></p>
				<p><a href="#">Подарочные карты</a></p>
			</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="" class="foot-link">Доставка и оплата</a></li>
					<li class="footer-list"><a href="" class="foot-link">Промокод</a></li>
					<li class="footer-list"><a href="" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="" class="foot-link">Контакты</a></li>
					<li class="footer-list"><a href="" class="foot-link">Адреса магазинов</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">Сервисы покупателя</p>
					<li class="footer-list"><a href="" class="foot-link">Подарочные сертифакы</a></li>
					<li class="footer-list"><a href="" class="foot-link">Бонусные карты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 2.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 3.png" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
