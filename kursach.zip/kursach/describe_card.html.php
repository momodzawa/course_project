<?php
// Подключение к базе данных
$host = 'localhost';
$db   = 'zoo_shop';
$user = 'momodzawa';
$pass = 'momo0808';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Соеденение: " . $conn->connect_error);
}

?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/describe_card.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php
					// Выборка категорий
					$sql = "SELECT * FROM categories";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					// Вывод категорий и их подкатегорий
					while($category = $result->fetch_assoc()) {
						echo '<li class="menu-list dropdown">
			 			<a class="nav-link" href="index.html.php?cat_id=' . $category['id'] . '" name="category_id">' . $category['name'] . '</a><div class="dropdown-content">';
						
						// Выборка подкатегорий для каждой категории
						$subSql = "SELECT * FROM subcategories WHERE category_id = " . $category['id'];
						$subResult = $conn->query($subSql);
						if ($subResult->num_rows > 0) {
							while($subcategory = $subResult->fetch_assoc()) {
								echo '<a href="?subcat_id=' . $subcategory['id'] . '" name="subcategory_id">' . $subcategory['name'] . '</a>';
							}
						} 
					}
				}
				?>
			</ul>
		</nav>
		<main>
			<section class="flex">
				<div>
					<img src="img/1 1.png" alt="image" class="img_tovar">
				</div>
				<div class="info">
					<h2>Корм для взрослых кошек Prime со вкусом индейки, 400гр</h2>
					<h3 class="price">500 руб.</h3>
					<div style="display: flex;"><img src="img/33.jpg" alt="ковер" style="width: 200px;"></div>
					<p>
						Сбалансированный рацион щенка во многом определяет здоровье собаки в 
						будущем, ее самочувствие, внешний вид и продолжительность жизни, а 
						также то, насколько будут проявлены в питомце ожидаемые породные
						черты: крепкая мускулатура, качество шерсти, пропорции тела.
						Наша команда ветеринарных врачей и диетологов разработала сухой 
						корм для щенков PRO PLAN, который содержит специальное сочетание
						питательных веществ для поддержки иммунной системы, нормального 
						роста и здоровья на долгие годы.
					</p>
					<h3>Характеристики</h3>
					<ul class="info_item">
						<li class="info_list">Артикул: 234567</li>
						<li class="info_list">Страна производства: Россия</li>
						<li class="info_list">Класс корма: премиум</li>
						<li class="info_list">Вес упаковки: 400гр</li>
						<li class="info_list">Вкус: индейка</li>
					</ul>
					<div class="button_group">
						<button type="submit" class="btn">В корзину</button>
						<button type="submit" class="btn_reverse">В избранное</button>	
					</div>
				</div>
		</section>
		<section class="mess">
			<h1 style="font-size: 36px;">Отзывы</h1>
			<div class="mess_cont">
				<h2>Наталья</h2>
				<p>С другой стороны начало повседневной работы по формированию позиции требует определени
					я и уточнения соответствующих условий активизации!</p>
				<img src="img/33.jpg" style="width: 100px;">
				<input type="submit" value="Подробнее" class="btn">
			</div>
			<div class="mess_cont">
				<h2>Наталья</h2>
				<p>С другой стороны начало повседневной работы по формированию позиции требует определени
					я и уточнения соответствующих условий активизации!</p>
				<img src="img/33.jpg" style="width: 100px;">
				<input type="submit" value="Подробнее" class="btn">
			</div>
			<div class="mess_cont">
				<h2>Наталья</h2>
				<p>С другой стороны начало повседневной работы по формированию позиции требует определени
					я и уточнения соответствующих условий активизации!</p>
				<img src="img/33.jpg" style="width: 100px;">
				<input type="submit" value="Подробнее" class="btn">
			</div>
		</section>
		<section>
			<h1 style="font-size: 36px;">Похожие товары</h1>
			<div class="carts">
				<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="img/1 1.png"
						alt="image"
						/>
					</a>
					<!-- Скидка на товар -->
					<div class="card__label">-10%</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p>500 руб.</p>
					<!-- Ссылка-название товара -->
					<a href="#" class="card__title">
						Корм для взрослых кошек Prime со вкусом индейки, 400гр
					</a>
					<button class="card__add">В корзину</button>
					</div>
				</div>

				<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="img/1 1.png"
						alt="image"
						/>
					</a>
					<!-- Скидка на товар -->
					<div class="card__label">-10%</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p>500 руб.</p>
					<!-- Ссылка-название товара -->
					<a href="#" class="card__title">
						Корм для взрослых кошек Prime со вкусом индейки, 400гр
					</a>
					<button class="card__add">В корзину</button>
					</div>
				</div>

				<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="img/1 1.png"
						alt="image"
						/>
					</a>
					<!-- Скидка на товар -->
					<div class="card__label">-10%</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p>500 руб.</p>
					<!-- Ссылка-название товара -->
					<a href="#" class="card__title">
						Корм для взрослых кошек Prime со вкусом индейки, 400гр
					</a>
					<button class="card__add">В корзину</button>
					</div>
				</div>

				<div class="card block">
					<div class="card__top">
					<a href="#" class="card__image">
						<img
						src="img/1 1.png"
						alt="image"
						/>
					</a>
					<!-- Скидка на товар -->
					<div class="card__label">-10%</div>
					</div>
					<!-- Нижняя часть -->
					<div class="card__bottom">
						<p>500 руб.</p>
					<!-- Ссылка-название товара -->
					<a href="#" class="card__title">
						Корм для взрослых кошек Prime со вкусом индейки, 400гр
					</a>
					<button class="card__add">В корзину</button>
					</div>
				</div>

			</div>
		</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="" class="foot-link">Доставка и оплата</a></li>
					<li class="footer-list"><a href="" class="foot-link">Промокод</a></li>
					<li class="footer-list"><a href="" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="" class="foot-link">Контакты</a></li>
					<li class="footer-list"><a href="" class="foot-link">Адреса магазинов</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">Сервисы покупателя</p>
					<li class="footer-list"><a href="" class="foot-link">Подарочные сертифакы</a></li>
					<li class="footer-list"><a href="" class="foot-link">Бонусные карты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 2.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 3.png" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
