<?php
	include 'php/link_db.php';
	include 'php/corzina.php';
	include 'php/prof_info.php';
?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/product_details.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon">
					<?php 
						if(isset($_COOKIE['login'])) { 
							echo "<a href='profile.html.php' class='nav-link'>". $user['first_name'] ."</a>";
						} else {
							echo '<a href="exit.html.php" class="nav-link">ВХОД</a>';
						}
					?>
				</li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'?>
			</ul>
		</nav>
		<main>
		<section class="flex">
		<?php
			$prod_id = isset($_GET['prod_id']) ? $_GET['prod_id'] : 0;

			$sql = "SELECT * FROM products WHERE id = " . $prod_id;
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
		?>
			<div>
				<img src="<?php echo $row['img'] ;?>" alt="image" class="img_tovar">
			</div>
			<div class="info">
				<h2><?php echo $row['name_prod']; ?></h2>
				<h3 class="price"><?php echo $row['price']; ?> p.</h3>
				<p><?php echo $row['description'] ;?></p>
				<div class="button_group">
					<form method="post">
						<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
						<button type="submit" class="btn" name="add_to_cart">В корзину</button>
						<button type="submit" class="add_to_favor" name="add_to_favor">В избранное</button>	
					</form>
				</div>
			</div>
		<?php
			}
		}
		?>
		</section>
		<section class="mess">
			<h1 style="font-size: 36px;">Отзывы</h1>
			<?php
				$sql = "SELECT users.login as login, reviews.text as text, reviews.id as id, reviews.img as img, reviews.count_star as star  
				FROM reviews inner join users on users.id = reviews.user_id 
				WHERE reviews.product_id = $prod_id";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					// Получаем данные отзыва из базы данных
					$sql = "SELECT count_star FROM reviews WHERE id = " . $row['id'];
					$result = $conn->query($sql);
					$review = $result->fetch_assoc();
			?>
			<div class="flex">
				<div class="mess_cont" id="app">
					<h2><?php echo $row['login'] ?></h2>
					<p><?php echo $row['star'] ?> из 5 звездочек ★</p>
					<p><?php echo $row['text'] ?></p>
					<img src="<?php echo $row['img'] ?>" alt="фото_отзыв" class="rev_img">
				</div>
			</div>
			<?php
				} 
			} else {
				echo '<p>Пока нет отзывов об этом товаре :( </p>';
			}
			?>
		</section>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
