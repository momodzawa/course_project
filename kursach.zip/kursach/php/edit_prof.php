<?php
// Проверка наличия ошибок
$err = "";
$err_email = "";
$err_log = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST['first_name'])) {
		$err .= "Укажите имя.<br>";
	}

	if (empty($_POST['last_name'])) {
		$err .= "Укажите фамилию.<br>";
	}

	if (empty($_POST['patronymic'])) {
		$err .= "Укажите отчество.<br>";
	}

	if (empty($_POST['login'])) {
		$err .= "Укажите логин.<br>";
	}

	if (empty($_POST['email'])) {
		$err_email .= "Укажите email.<br>";
	} else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		$err_email .= "Неверный формат email.<br>";
	} else {
		// Проверка уникальности email
		$sql = "SELECT * FROM users WHERE email = '" . $_POST['email'] . "'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			$err_email .= "Этот email уже зарегистрирован.<br>";
		}
		// Проверка уникальности login	
		$sql = "SELECT * FROM users WHERE login = '" . $_POST['login'] . "'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			$err_log = "<p>Логин уже существует. Пожалуйста, выберите другой логин.</p>";
		} 
	}
}
?>