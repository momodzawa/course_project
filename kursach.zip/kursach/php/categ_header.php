<?php
  // Выборка категорий
  $sql = "SELECT * FROM categories";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
  // Вывод категорий и их подкатегорий
  while($category = $result->fetch_assoc()) {
    echo '<li class="menu-list dropdown">
    <a class="nav-link" href="index.html.php?cat_id=' . $category['id'] . '" name="category_id">' . $category['name'] . '</a><div class="dropdown-content">';
    
    // Выборка подкатегорий для каждой категории
    $subSql = "SELECT * FROM subcategories WHERE category_id = " . $category['id'];
    $subResult = $conn->query($subSql);
    if ($subResult->num_rows > 0) {
      while($subcategory = $subResult->fetch_assoc()) {
        echo '<a href="?subcat_id=' . $subcategory['id'] . '" name="subcategory_id">' . $subcategory['name'] . '</a>';
      }
    } 
  }
}

?>