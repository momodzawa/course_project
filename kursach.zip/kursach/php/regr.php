<?php
// Проверка наличия ошибок
$err = "";
$err_email = "";
$err_pass = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST['first_name'])) {
		$err .= "Укажите имя.<br>";
	}

	if (empty($_POST['last_name'])) {
		$err .= "Укажите фамилию.<br>";
	}

	if (empty($_POST['patronymic'])) {
		$err .= "Укажите отчество.<br>";
	}

	if (empty($_POST['login'])) {
		$err .= "Укажите логин.<br>";
	}

	if (empty($_POST['email'])) {
		$err_email .= "Укажите email.<br>";
	} else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		$err_email .= "Неверный формат email.<br>";
	} else {
		// Проверка уникальности email
		$sql = "SELECT * FROM users WHERE email = '" . $_POST['email'] . "'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			$err_email .= "Этот email уже зарегистрирован.<br>";
		}
		// Проверка уникальности login	
		$sql = "SELECT * FROM users WHERE login = '" . $_POST['login'] . "'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			echo "<p>Логин уже существует. Пожалуйста, выберите другой логин.</p>";
		} 
	}

	if (empty($_POST['password'])) {
		$err_pass .= "Укажите пароль.<br>";
	} else if (strlen($_POST['password']) < 6) {
		$err_pass .= "Пароль должен содержать не менее 6 символов.<br>";
	}

	if ($_POST['password'] != $_POST['confirm-password']) {
		$err_pass .= "Пароли не совпадают.<br>";
	}

	if (empty($err) && empty($err_email) && empty($err_pass)) {

		$hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

		$sql = "INSERT INTO users (first_name, last_name, patronymic, email, login, password) VALUES ('" . $_POST['first_name'] . "', '" . $_POST['last_name'] . "', '" . $_POST['patronymic'] . "', '" . $_POST['email'] . "', '" . $_POST['login'] . "', '" . $hashed_password . "')";
		if ($conn->query($sql) === TRUE) {
			header('Location: exit.html.php');
			exit;
		} else {
			$err .= "Ошибка при регистрации. Попробуйте еще раз.<br>";
		}
	}
}
?>