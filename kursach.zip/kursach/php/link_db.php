<?php
// Подключение к базе данных
$host = 'localhost';
$db   = 'zoo_shop';
$user = 'momodzawa';
$pass = 'momo0808';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Соеденение: " . $conn->connect_error);
}


?>