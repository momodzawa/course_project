<?php
include 'php/link_db.php';
include 'php/regr.php';
?>
  
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/registration.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block two_nav" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php include 'php/categ_header.php'; ?>
			</ul>
		</nav>
		<main>
			<form class="registration-form" method="post">
				<h2>Регистрация</h2>
				<div>
					<label for="first_name">Имя:</label>
					<input type="text" id="first_name" name="first_name">
				</div>
				<div>
					<label for="last_name">Фамилия:</label>
					<input type="text" id="last_name" name="last_name">
				</div>
				<div>
					<label for="patronymic">Отчество:</label>
					<input type="text" id="patronymic" name="patronymic">
				</div>
				<div>
					<label for="email">Email:</label>
					<input type="email" id="email" name="email">
					<span style="color: red;"><?php echo $err_email; ?></span>
				</div>
				<div>
					<label for="login">Логин:</label>
					<input type="text" id="login" name="login">
				</div>
				<div>
					<label for="password">Пароль:</label>
					<input type="password" id="password" name="password">
					<span style="color: red;"><?php echo $err_pass; ?></span>
				</div>
				<div>
					<label for="confirm-password">Повторите пароль:</label>
					<input type="password" id="confirm-password" name="confirm-password">
					<span style="color: red;"><?php echo $err_pass; ?></span>
				</div>
				<span style="color: red;"><?php echo $err; ?></span>
				<button type="submit" class="btn">Зарегистрироваться</button>
			</form>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="foot-info.php?link_id=1" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=2" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=3" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="foot-info.php?link_id=4" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="foot-info.php?link_id=5" class="foot-link">Контакты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="https://web.telegram.org"><img class="social-img" src="img/2 2.svg" alt="image"></a>
					<a href="https://vk.com"><img class="social-img" src="img/2 3.svg" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="#" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
