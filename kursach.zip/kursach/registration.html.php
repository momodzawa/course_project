<?php
// Подключение к базе данных
$host = 'localhost';
$db   = 'zoo_shop';
$user = 'momodzawa';
$pass = 'momo0808';
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Соеденение: " . $conn->connect_error);
}

$err = $err_pass = $err_email = '';
  
function validate_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
  }
  
// Проверка, была ли отправлена форма
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	// Проверка наличия и валидация полей ФИО, почты и пароля
	$first_name = $last_name = $patronymic = $email = $password = $confirm_password = '';
	$err = $err_pass = $err_email ='';
  
	if(empty($_POST["first_name"]) || empty($_POST["last_name"]) || empty($_POST["email"]) || empty($_POST["password"]) || empty($_POST["confirm-password"]) || empty($_POST["patronymic"])) {
	  $err = "Все поля должны быть заполнены";
	} else {
	  $first_name = validate_input($_POST["first_name"]);
	  $last_name = validate_input($_POST["last_name"]);
	  $patronymic = validate_input($_POST["patronymic"]);
  
	  if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
		$err_email = "Неправильный формат электронной почты";
	  } else {
		$password = $_POST["password"];
		$confirm_password = $_POST["confirm-password"];
	
		if ($password != $confirm_password) {
			$err_pass = "Пароли не совпадают";
		} else {
		  $hashed_password = password_hash($password, PASSWORD_DEFAULT);
		}
	}
}
  
	// // Если все поля корректны, выполняем запись в базу данных
	// if ($first_name && $last_name && $patronymic && $email && $password && $confirm_password) {
	// // Подключение к базе данных
	$host = 'localhost';
	$db   = 'zoo_shop';
	$user = 'momodzawa';
	$pass = 'momo0808';
	$charset = 'utf8mb4';

	$conn = new mysqli($host, $user, $pass, $db);

	if ($conn->connect_error) {
	die("Соеденение: " . $conn->connect_error);
	}
  
	  // Подготовка и выполнение запроса
	  $stmt = $conn->prepare('INSERT INTO users (first_name, last_name, patronymic, email, password) VALUES (?, ?, ?, ?, ?)');
	  $stmt->bind_param('sssss', $first_name, $last_name, $patronymic, $email, $hashed_password);
	  $stmt->execute();
  
	//   header('Location: exit.html.php');
	}
  


?>
<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
		<link href="style/registration.css" rel="stylesheet" />
		<title>Лапки</title>
	</head>
	<body>
		<nav class="navigation">
			<div class="logo"><img src="img/logo 1.png" alt="logo"></div>
			<ul class="item start">
				<li class="list"><img src="img/image 1.png" alt="image" class="icon"><a href="exit.html.php" class="nav-link">ВХОД</a></li>
				<li class="list"><img src="img/4 4.png" alt="image" class="icon"><a href="favourite.html.php" class="nav-link">ИЗБРАННОЕ</a></li>
				<li class="list"><img src="img/image 3.png" alt="image" class="icon"><a href="corzina.html.php" class="nav-link">КОРЗИНА</a></li>
			</ul>
		</nav>
		<nav class="navigation block" style="margin-top: 10px; margin-bottom: 20px;">
			<ul class="menu">
				<?php
					// Выборка категорий
					$sql = "SELECT * FROM categories";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					// Вывод категорий и их подкатегорий
					while($category = $result->fetch_assoc()) {
						echo '<li class="menu-list dropdown">
			 			<a class="nav-link" href="index.html.php?cat_id=' . $category['id'] . '" name="category_id">' . $category['name'] . '</a><div class="dropdown-content">';
						
						// Выборка подкатегорий для каждой категории
						$subSql = "SELECT * FROM subcategories WHERE category_id = " . $category['id'];
						$subResult = $conn->query($subSql);
						if ($subResult->num_rows > 0) {
							while($subcategory = $subResult->fetch_assoc()) {
								echo '<a href="?subcat_id=' . $subcategory['id'] . '" name="subcategory_id">' . $subcategory['name'] . '</a>';
							}
						} 
					}
				}
				?>
			</ul>
		</nav>
		<main>
			<form class="registration-form" method="post" action="exit.html.php">
				<h2>Регистрация</h2>
				<div>
					<label for="first_name">Имя:</label>
					<input type="text" id="first_name" name="first_name" require>
				</div>
				<div>
					<label for="last_name">Фамилия:</label>
					<input type="text" id="last_name" name="last_name" require>
				</div>
				<div>
					<label for="patronymic">Отчество:</label>
					<input type="text" id="patronymic" name="patronymic" require>
				</div>
				<div>
					<label for="email">Email:</label>
					<input type="email" id="email" name="email" require>
					<span style="color: red;"><?php echo $err_email; ?></span>
				</div>
				<div>
					<label for="password">Пароль:</label>
					<input type="password" id="password" name="password" require>
					<span style="color: red;"><?php echo $err_pass; ?></span>
				</div>
				<div>
					<label for="confirm-password">Повторите пароль:</label>
					<input type="password" id="confirm-password" name="confirm-password" require>
					<span style="color: red;"><?php echo $err_pass; ?></span>
				</div>
				<span style="color: red;"><?php echo $err; ?></span>
				<button type="submit" class="btn">Зарегистрироваться</button>
			</form>
		</main>
		<footer class="page-footer">
			<div class="conteiner">
				<ul class="footer-item">
					<p class="price">Интернет-магазин</p>
					<li class="footer-list"><a href="" class="foot-link">О магазине</a></li>
					<li class="footer-list"><a href="" class="foot-link">Как сделать заказ</a></li>
					<li class="footer-list"><a href="" class="foot-link">Доставка и оплата</a></li>
					<li class="footer-list"><a href="" class="foot-link">Промокод</a></li>
					<li class="footer-list"><a href="" class="foot-link">Политика конфидециальности</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">О нас</p>
					<li class="footer-list"><a href="" class="foot-link">Обратная связь</a></li>
					<li class="footer-list"><a href="" class="foot-link">Контакты</a></li>
					<li class="footer-list"><a href="" class="foot-link">Адреса магазинов</a></li>
				</ul>
				<ul class="footer-item">
					<p class="price">Сервисы покупателя</p>
					<li class="footer-list"><a href="" class="foot-link">Подарочные сертифакы</a></li>
					<li class="footer-list"><a href="" class="foot-link">Бонусные карты</a></li>
				</ul>
				<div class="social">
					<a href="#"><img class="social-img" src="img/2 1.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 2.png" alt="image"></a>
					<a href="#"><img class="social-img" src="img/2 3.png" alt="image"></a>
				</div>
			</div><br><br>
			<div>
				<p>© 2024 Зоомагазин «Лапки»<br><a href="" class="foot-link">Правовые условия пользования сайтом</a></p>
			</div>
		</footer>
	</body>
</html>
